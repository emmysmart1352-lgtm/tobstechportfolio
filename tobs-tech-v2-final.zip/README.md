# Tob's Tech v2

Multi-page static portfolio website.

Pages: index.html, work.html, services.html, about.html, contact.html.

Put your photo in the same folder as these files and name it `toby.png`.

Deploy by uploading the files to GitHub and importing the repository into Vercel. No build command is required.

The case studies are explicitly concept, personal, or reconstructed portfolio studies. Replace them with verified client work when available.
